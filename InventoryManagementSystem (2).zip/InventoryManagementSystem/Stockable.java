interface Stockable {
    void restock(int quantity) throws InventoryException;
    void sell(int quantity) throws InventoryException;
    boolean isLowStock();
    String getItemDetails();
}