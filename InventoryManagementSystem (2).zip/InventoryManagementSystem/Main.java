import java.time.LocalDate;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InventoryManagementSystem inventory = new InventoryManagementSystem();

        Supplier supplier1 = new Supplier("S001", "Fresh Foods", "contact_ut_freshfoods.com");
        Supplier supplier2 = new Supplier("S002", "Tech Supplies", "contact_ut_techsupplies.com");
        try {
            inventory.addItem(new PerishableItem("I001", "Milk", 20, 2.99, supplier1, LocalDate.of(2025, 6, 10)));
            inventory.addItem(new ElectronicItem("I002", "Laptop", 5, 999.99, supplier2, 24));
        } catch (InventoryException e) {
            System.out.println("Error: " + e.getMessage());
        }

        while (true) {
            System.out.println("\nInventory Menu:");
            System.out.println("1. Add Item");
            System.out.println("2. Restock Item");
            System.out.println("3. Sell Item");
            System.out.println("4. Show Inventory");
            System.out.println("5. Check Low Stock");
            System.out.println("6. Search Items");
            System.out.println("7. Exit");
            System.out.print("Choose (1-7): ");

            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    try {
                        System.out.print("Item type (1=Perishable, 2=Electronic): ");
                        int type = Integer.parseInt(scanner.nextLine());
                        System.out.print("Item ID: ");
                        String id = scanner.nextLine();
                        System.out.print("Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Stock: ");
                        int stock = Integer.parseInt(scanner.nextLine());
                        System.out.print("Price: ");
                        double price = Double.parseDouble(scanner.nextLine());
                        System.out.print("Supplier Name: ");
                        String supName = scanner.nextLine();
                        System.out.print("Supplier Contact: ");
                        String contact = scanner.nextLine();
                        Supplier supplier = new Supplier("S" + id, supName, contact);

                        if (type == 1) {
                            System.out.print("Expiry Date (YYYY-MM-DD): ");
                            LocalDate expiry = LocalDate.parse(scanner.nextLine());
                            inventory.addItem(new PerishableItem(id, name, stock, price, supplier, expiry));
                        } else if (type == 2) {
                            System.out.print("Warranty Months: ");
                            int warranty = Integer.parseInt(scanner.nextLine());
                            inventory.addItem(new ElectronicItem(id, name, stock, price, supplier, warranty));
                        } else {
                            System.out.println("Invalid item type.");
                        }
                        System.out.println("Item added.");
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 2:
                    try {
                        System.out.print("Item ID: ");
                        String id = scanner.nextLine();
                        System.out.print("Quantity: ");
                        int qty = Integer.parseInt(scanner.nextLine());
                        inventory.restockItem(id, qty);
                        System.out.println("Restocked.");
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 3:
                    try {
                        System.out.print("Item ID: ");
                        String id = scanner.nextLine();
                        System.out.print("Quantity: ");
                        int qty = Integer.parseInt(scanner.nextLine());
                        inventory.sellItem(id, qty);
                        System.out.println("Sold.");
                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 4:
                    inventory.displayInventory();
                    break;

                case 5:
                    System.out.println("Low Stock Items:");
                    boolean lowStock = false;
                    for (Stockable item : inventory.getItems()) {
                        if (item.isLowStock()) {
                            lowStock = true;
                            System.out.println(item.getItemDetails());
                        }
                    }
                    if (!lowStock) {
                        System.out.println("No low stock items.");
                    }
                    break;

                case 6:
                    System.out.print("Search name: ");
                    String query = scanner.nextLine();
                    inventory.searchItemsByName(query);
                    break;

                case 7:
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Choose 1-7.");
            }
        }
    }
}