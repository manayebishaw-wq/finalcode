import java.time.LocalDate;

abstract class Item implements Stockable {
    private String itemId;
    private String name;
    private int stockLevel;
    private double price;
    private Supplier supplier;

    public Item(String itemId, String name, int stockLevel, double price, Supplier supplier) {
        this.itemId = itemId;
        this.name = name;
        this.stockLevel = stockLevel;
        this.price = price;
        this.supplier = supplier;
    }

    public String getItemId() { return itemId; }
    public String getName() { return name; }
    public int getStockLevel() { return stockLevel; }
    public double getPrice() { return price; }
    public Supplier getSupplier() { return supplier; }

    protected void setStockLevel(int stockLevel) throws InventoryException {
        if (stockLevel < 0) {
            throw new InventoryException("Stock level cannot be negative for item: " + name);
        }
        this.stockLevel = stockLevel;
    }

    @Override
    public boolean isLowStock() {
        return stockLevel < 10;
    }

    @Override
    public String getItemDetails() {
        return "ID:" + itemId + ", Name:" + name + ", Stock:" + stockLevel + ", Price: $" + price +
               ", Supplier: " + supplier.getName();
    }
}