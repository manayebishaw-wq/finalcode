class ElectronicItem extends Item {
    private int warrantyMonths;

    public ElectronicItem(String itemId, String name, int stockLevel, double price, Supplier supplier, int warrantyMonths) {
        super(itemId, name, stockLevel, price, supplier);
        this.warrantyMonths = warrantyMonths;
    }

    @Override
    public void restock(int quantity) throws InventoryException {
        if (quantity <= 0) {
            throw new InventoryException("Restock quantity must be positive for " + getName());
        }
        setStockLevel(getStockLevel() + quantity);
    }

    @Override
    public void sell(int quantity) throws InventoryException {
        if (quantity <= 0) {
            throw new InventoryException("Sell quantity must be positive for " + getName());
        }
        if (quantity > getStockLevel()) {
            throw new InventoryException("Insufficient stock for " + getName());
        }
        setStockLevel(getStockLevel() - quantity);
    }

    @Override
    public String getItemDetails() {
        return super.getItemDetails() + ", Warranty: " + warrantyMonths + " months";
    }
}