import java.util.ArrayList;

class InventoryManagementSystem {
    private ArrayList<Stockable> items;

    public InventoryManagementSystem() {
        this.items = new ArrayList<>();
    }

    public void addItem(Stockable item) throws Exception {
        if (item instanceof Item) {
            String newItemId = ((Item) item).getItemId();
            for (Stockable existingItem : items) {
                if (existingItem instanceof Item && ((Item) existingItem).getItemId().equals(newItemId)) {
                    throw new Exception("Item with ID " + newItemId + " already exists.");
                }
            }
        }
        items.add(item);
    }

    public void restockItem(String itemId, int quantity) throws Exception {
        Stockable item = findItemById(itemId);
        item.restock(quantity);
        if (item.isLowStock()) {
            generateReorderAlert(item);
        }
    }

    public void sellItem(String itemId, int quantity) throws Exception {
        Stockable item = findItemById(itemId);
        item.sell(quantity);
        if (item.isLowStock()) {
            generateReorderAlert(item);
        }
    }

    public void searchItemsByName(String query) {
        boolean found = false;
        System.out.println("Search Results for '" + query + "':");
        for (Stockable item : items) {
            if (item instanceof Item && ((Item) item).getName().toLowerCase().contains(query.toLowerCase())) {
                System.out.println(item.getItemDetails());
                found = true;
            }
        }
        if (!found) {
            System.out.println("No items found matching '" + query + "'.");
        }
    }

    private Stockable findItemById(String itemId) throws Exception {
        for (Stockable item : items) {
            if (item instanceof Item && ((Item) item).getItemId().equals(itemId)) {
                return item;
            }
        }
        throw new Exception("Item with ID " + itemId + " not found");
    }

    private void generateReorderAlert(Stockable item) {
        Item it = (Item) item;
        System.out.println("ALERT: Low stock for " + it.getName() + ". Contact supplier: " +
                           it.getSupplier().getName() + " (" + it.getSupplier().getContactInfo() + ")");
    }

    public void displayInventory() {
        System.out.println("Current Inventory:");
        if (items.isEmpty()) {
            System.out.println("No items in inventory.");
        } else {
            for (Stockable item : items) {
                System.out.println(item.getItemDetails());
            }
        }
    }

    public Stockable[] getItems() {
        return items.toArray(new Stockable[0]);
    }
}