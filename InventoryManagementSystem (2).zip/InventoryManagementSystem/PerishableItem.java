import java.time.LocalDate;

class PerishableItem extends Item {
    private LocalDate expiryDate;

    public PerishableItem(String itemId, String name, int stockLevel, double price, Supplier supplier, LocalDate expiryDate) {
        super(itemId, name, stockLevel, price, supplier);
        this.expiryDate = expiryDate;
    }

    @Override
    public void restock(int quantity) throws InventoryException {
        if (quantity <= 0) {
            throw new InventoryException("Restock quantity must be positive for " + getName());
        }
        if (expiryDate.isBefore(LocalDate.now())) {
            throw new InventoryException("Cannot restock expired item: " + getName());
        }
        setStockLevel(getStockLevel() + quantity);
    }

    @Override
    public void sell(int quantity) throws InventoryException {
        if (quantity <= 0) {
            throw new InventoryException("Sell quantity must be positive for " + getName());
        }
        if (expiryDate.isBefore(LocalDate.now())) {
            throw new InventoryException("Cannot sell expired item: " + getName());
        }
        if (quantity > getStockLevel()) {
            throw new InventoryException("Insufficient stock for " + getName());
        }
        setStockLevel(getStockLevel() - quantity);
    }

    @Override
    public String getItemDetails() {
        return super.getItemDetails() + ", Expiry: " + expiryDate;
    }
}